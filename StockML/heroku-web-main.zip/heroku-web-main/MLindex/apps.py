from django.apps import AppConfig


class MlindexConfig(AppConfig):
    name = 'MLindex'
